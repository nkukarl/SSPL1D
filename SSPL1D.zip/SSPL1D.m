% This code calculates the steady state PL spectra for silicon wafers,
% characterised by a injection level dependent bulk lifetime and two
% injection level dependent surface recombination velocities.
% It is based on a one-dimensional model and firstly calculates the 
% steady state excess minority carrier density as a function
% of depth into silicon and then the raw PL spectra.
% PL spectra measured by a Silicon detector and a InGaAs detector are also
% calculated.

% Temperature
T = 300; % Ambient temperature

% Intrinsic carrier concentration
% Altermatt, 2011, Models for numerical device simulations of crystalline
% silicon solar cells - a review

% Radiative recombination coefficient
% Nguyen et al, 2014, Temperature dependence of the radiative recombination
% coefficient in crystalline silicon from spectral photoluminescence
% N.B. Data only cover 90 to 363 K, B for temperature outside this range is
% extrapolated

% Auger recombination coefficient
% Altermatt, 1997, Assessment and parameterisation of Coulomb-enhanced
% Auger recombination coefficients in lowly injected crystalline silicon

% SRH recombination

% SRH bulk
taup0 = 250e-6;
taun0 = 250e-6;
Ei = 0;
Etb = Ei + 0;

% SRH surface
Sp0f = 100;
Sn0f = 100;
Sp0r = 100;
Sn0r = 100;

Ets = Ei + 0;

% Diffusivity,  using PC1D model for mobility
dop_type = 'P';
Nx = 1.5e16;

% Sample thickness
W = 0.018;

lambda1 = 808;
suns = 0.1;
% External, internal front and internal back reflection
% of excitation wavelength
% Green, 2011, Analytical expressions for spectral composition of band
% photoluminescence from silicon wafers and bricks
Rf1 = 0;
Rfn1 = 0;
Rbn1 = 0;

% Detection wavelengths range specification
Wav_detec_low = 900; % lower range of detection wavelength
Wav_detec_up = 1300; % uppper range of detection wavelength
Wav_detec_step = 10; % detection wavelength step
Wav_detec = linspace(Wav_detec_low, Wav_detec_up, ...
    (Wav_detec_up - Wav_detec_low) / Wav_detec_step + 1)';
% N.B. Data provided by Green is in 10 nm step from 250 upto 1450 nm

% Absorption coefficient from Green, 2008, Self-consistent optical
% parameters of intrinsic silicon at 300K including temperature coefficients
% N.B. Data cover 249 to 473 K, the accuracy of the absorption coefficient
% and refractive index at temperature outside this range cannot be guaranteed

% External, internal front and internal back reflection
% of detection wavelengths
% Green, 2011, Analytical expressions for spectral composition of band
% photoluminescence from silicon wafers and bricks
Rf2 = 0 * ones(size(Wav_detec));
Rfn2 = 0 * ones(size(Wav_detec));
Rbn2 = 0 * ones(size(Wav_detec));

% PL calculation using models by Schinke et al., 2013, Modeling the
% Spectral Luminescence Emission of Silicon Solar Cells and Wafers,
% Eq. (5) and (7)

SSPL1D_core(T, taup0, taun0, Ei, Etb, ...
    Sp0f, Sn0f, Sp0r, Sn0r, Ets, ...
    dop_type, Nx, W, ...
    lambda1, suns, Rf1, Rfn1, Rbn1, ...
    Wav_detec, Rf2, Rfn2, Rbn2)

% Data automatically saved using filename with a suffix of current time 
% in the form of YYYYMMDDhhmmss (avoid filename clash)